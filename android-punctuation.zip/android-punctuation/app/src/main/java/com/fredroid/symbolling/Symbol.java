package com.fredroid.symbolling;

/**
 * Created by Administrator on 24/07/2017.
 */

public class Symbol {
    public String strmark;
    public String strspell;
    public Symbol(String strmark, String strspell) {
        this.strmark = strmark;
        this.strspell = strspell;
    }
}
